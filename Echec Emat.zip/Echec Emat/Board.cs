﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace projet
{
    public class Board
    {
        private Piece[,] squares;
        private Player player1;
        private Player player2;
        private Player currentPlayer;
        private List<string> player1Moves = new List<string>();
        private List<string> player2Moves = new List<string>();



        public Player CurrentPlayer
        {
            get { return currentPlayer; }
        }
        public Board(Player p1, Player p2)
        {
            player1 = p1;
            player2 = p2;
          


            currentPlayer = player2;
            squares = new Piece[8, 8];

            InitializeBoard();
        
        }
       

        // Méthode pour enregistrer le coup dans l'historique du joueur courant
        public void RecordMove(string move)
        {
            // Enregistrez le mouvement dans l'historique du joueur courant
            if (currentPlayer == player2)
            {
                player1Moves.Add(move);
            }
            else if (currentPlayer == player1)
            {
                player2Moves.Add(move);
            }
        }
        public List<string> GetPlayer1Moves()
        {
            return player1Moves;
        }

        public List<string> GetPlayer2Moves()
        {
            return player2Moves;
        }




        public Piece GetPieceAt(int x, int y)
        {
            // Vérifie si les coordonnées sont en dehors des limites du plateau
            if (x < 0 || x >= 8 || y < 0 || y >= 8)
            {
                // Gère les coordonnées hors limites (peut-être renvoyer null ou lever une exception)
                return null;
            }

            // Retourne la pièce à ces coordonnées
            return squares[x, y];
        }



        private void InitializeBoard()
        {
            squares[0, 0] = new Rook(PlayerColor.White);
            squares[0, 1] = new Knight(PlayerColor.White);
            squares[0, 2] = new Bishop(PlayerColor.White);
            squares[0, 3] = new Queen(PlayerColor.White);
            squares[0, 4] = new King(PlayerColor.White);
            squares[0, 5] = new Bishop(PlayerColor.White);
            squares[0, 6] = new Knight(PlayerColor.White);
            squares[0, 7] = new Rook(PlayerColor.White);

            squares[7, 0] = new Rook(PlayerColor.Black);
            squares[7, 1] = new Knight(PlayerColor.Black);
            squares[7, 2] = new Bishop(PlayerColor.Black);
            squares[7, 3] = new Queen(PlayerColor.Black);
            squares[7, 4] = new King(PlayerColor.Black);
            squares[7, 5] = new Bishop(PlayerColor.Black);
            squares[7, 6] = new Knight(PlayerColor.Black);
            squares[7, 7] = new Rook(PlayerColor.Black);

            for (int i = 0; i < 8; i++)
            {
                squares[1, i] = new Pawn(PlayerColor.White);
                squares[6, i] = new Pawn(PlayerColor.Black);
            }

            // Les autres cases restantes sont vides
            for (int i = 2; i < 6; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    squares[i, j] = null;
                }
            }
        }

        //affichage
        public void DisplayBoard(Board board)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.WriteLine("  8 7 6 5 4 3 2 1");
            for (int i = 0; i < 8; i++)
            {
                Console.Write((char)('a' + i) + " ");
                for (int j = 0; j < 8; j++)
                {
                    if ((i + j) % 2 == 0)
                        Console.BackgroundColor = ConsoleColor.DarkYellow;
                    else
                        Console.BackgroundColor = ConsoleColor.Red;

                    Piece piece = board.GetPieceAt(j, i);
                    if (piece == null)
                        Console.Write("  ");
                    else
                    {
                        if (piece.PieceColor == PlayerColor.White)
                            Console.ForegroundColor = ConsoleColor.White;
                        else
                            Console.ForegroundColor = ConsoleColor.Black;

                        char symbol = GetPieceSymbol(piece);
                        Console.Write(symbol + " ");
                    }
                }
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine((char)('a' + i)); // Ajoutez les lettres de colonne en bas
            }
            Console.WriteLine("  8 7 6 5 4 3 2 1");
        }
        static char GetPieceSymbol(Piece piece)
        {
            switch (piece)
            {
                case King _:
                    return piece.PieceColor == PlayerColor.White ? '♔' : '♚';
                case Queen _:
                    return piece.PieceColor == PlayerColor.White ? '♕' : '♛';
                case Rook _:
                    return piece.PieceColor == PlayerColor.White ? '♖' : '♜';
                case Bishop _:
                    return piece.PieceColor == PlayerColor.White ? '♗' : '♝';
                case Knight _:
                    return piece.PieceColor == PlayerColor.White ? '♘' : '♞';
                case Pawn _:
                    return piece.PieceColor == PlayerColor.White ? '♙' : '♟';
                default:
                    return ' ';
            }
        }

        public bool IsMoveValid(int startX, int startY, int targetX, int targetY)
        {
            Piece piece = squares[startY, startX];

            if (piece == null)
            {
                // Pas de pièce à la position de départ
                Console.WriteLine("Pas de piece dans la position de départ");
                Console.ReadLine();
                return false;
                
            }
            if( piece.PieceColor != currentPlayer.Color)
            {
                // Pièce non trouvée ou appartient à l'autre joueur
                Console.WriteLine("Sélectionnez une pièce appartenant à votre joueur");
                Console.ReadLine();
                return false;
            }

            // Vérifier si la case cible est en dehors du plateau
            if (targetX < 0 || targetX >= 8 || targetY < 0 || targetY >= 8)
            {

                Console.WriteLine("La case cible est en dehors du plateau");
                Console.ReadLine();
                return false;
                
            }

            // Vérifier si le mouvement est valide pour cette pièce spécifique
            return piece.IsValidMove(startX, startY, targetX, targetY, squares);
            
            

        }


       





        public void MakeMove(int startX, int startY, int targetX, int targetY)
        {


            if (!IsMoveValid(startX, startY, targetX, targetY))
            {
                // Le mouvement n'est pas valide, ne rien faire
                Console.WriteLine("Le mouvement est invalide. Veillez ressayer");
                Console.ReadLine();

                return;
            }

            Piece piece = squares[startY, startX];

            // Enregistrer le mouvement effectué
            // Si la pièce est une tour, un roi ou un pion, par exemple, mettre à jour la propriété HasMoved
            if (piece is Rook || piece is King || piece is Pawn || piece is Queen || piece is Knight)
            {
                piece.HasMoved = true;
                
            }
         
            // Effectuer le déplacement de la pièce vers la nouvelle position
            squares[startY, startX] = null;
            squares[targetY, targetX] = piece;


            // Enregistrez le mouvement dans l'historique du joueur courant
            string moveString = $"{(char)('a' + startX)}{8 - startY}{(char)('a' + targetX)}{8 - targetY}";
           
            this.RecordMove(moveString);

            SwitchPlayer();
            

        }

        public Piece[,] GetBoard()
        {
            return squares; // Retourne le tableau représentant le plateau
        }


        public void SwitchPlayer()
{
  currentPlayer = (currentPlayer == player1) ? player2 : player1;
}

        public bool IsKingCaptured(PlayerColor color, Piece[,] board)
        {
            for (int y = 0; y < 8; y++)
            {
                for (int x = 0; x < 8; x++)
                {
                    Piece piece = board[y, x];
                    if (piece is King && piece.PieceColor == color)
                    {
                        return false; // Le roi de la couleur spécifiée est toujours sur le plateau
                    }
                }
            }
            return true; // Le roi de la couleur spécifiée n'est pas présent sur le plateau
        }

        public bool IsKingInCheck(PlayerColor color)
        {
            int kingX = -1;
            int kingY = -1;

            // Trouver les coordonnées du roi
            for (int y = 0; y < 8; y++)
            {
                for (int x = 0; x < 8; x++)
                {
                    Piece piece = squares[y, x];
                    if (piece is King && piece.PieceColor == color)
                    {
                        kingX = x;
                        kingY = y;
                        break;
                    }
                }
                if (kingX != -1 && kingY != -1)
                    break;
            }

            if (kingX == -1 || kingY == -1)
            {
               // Console.WriteLine("Roi non trouvé !");
                return false;
            }

            // Vérifier si le roi est attaqué par une pièce adverse
            for (int y = 0; y < 8; y++)
            {
                for (int x = 0; x < 8; x++)
                {
                    Piece attackingPiece = squares[y, x];
                    if (attackingPiece != null && attackingPiece.PieceColor != color)
                    {
                        if (attackingPiece.IsValidMove(x, y, kingX, kingY, squares))
                        {
                            Console.WriteLine("Echec!!!");
                            return true;
                        }
                    }
                }
            }

            return false;
        }


        public bool IsStalemate(PlayerColor color)
        {
            // Vérifie si le roi de la couleur spécifiée n'est pas en échec
            if (!IsKingInCheck(color))
            {
                for (int y = 0; y < 8; y++)
                {
                    for (int x = 0; x < 8; x++)
                    {
                        Piece piece = squares[y, x];
                        if (piece != null && piece.PieceColor == color)
                        {
                            for (int targetY = 0; targetY < 8; targetY++)
                            {
                                for (int targetX = 0; targetX < 8; targetX++)
                                {
                                    if (piece.IsValidMove(x, y, targetX, targetY, squares))
                                    {
                                        // Un mouvement est possible, donc ce n'est pas un stalemate
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }

                // Aucun mouvement possible pour les pièces du joueur, c'est un stalemate
                return true;
            }

            // Si le roi est en échec, ce n'est pas un stalemate
            return false;
        }





    }

}
