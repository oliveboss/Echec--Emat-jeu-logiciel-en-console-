﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public class Bishop : Piece
    {
        public Bishop(PlayerColor color) : base(color) { Symbol = "B"; }

        public override bool IsValidMove(int startX, int startY, int targetX, int targetY, Piece[,] board)
        {
            // Vérification si le mouvement est diagonal
            if (Math.Abs(targetX - startX) != Math.Abs(targetY - startY))
                return false;

            int xDirection = (targetX - startX > 0) ? 1 : -1;
            int yDirection = (targetY - startY > 0) ? 1 : -1;

            int x = startX + xDirection;
            int y = startY + yDirection;

            // Vérification des cases sur le chemin du mouvement
            while (x != targetX && y != targetY)
            {
                if (board[y, x] != null)
                    return false;

                x += xDirection;
                y += yDirection;
            }

            // Vérification de la case cible
            Piece targetPiece = board[targetY, targetX];
            return (targetPiece == null || targetPiece.PieceColor != PieceColor);
        }
    }

}
