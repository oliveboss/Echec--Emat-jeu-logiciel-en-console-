﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public class Knight : Piece

    {
        
        public Knight(PlayerColor color) : base(color) { Symbol = "q"; }

        public override bool IsValidMove(int startX, int startY, int targetX, int targetY, Piece[,] board)
        {
            int diffX = Math.Abs(targetX - startX);
            int diffY = Math.Abs(targetY - startY);

            if ((diffX == 1 && diffY == 2) || (diffX == 2 && diffY == 1))
            {
                Piece targetPiece = board[targetY, targetX];
                if (targetPiece == null || targetPiece.PieceColor != PieceColor)
                {
                    return true;
                }
            }

            return false; // Si le mouvement n'est pas valide
        }
    }

}
