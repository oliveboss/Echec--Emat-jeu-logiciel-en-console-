﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public class Pawn : Piece
    {
        private bool hasMoved = false;

        public Pawn(PlayerColor color) : base(color) { Symbol = "P"; }

        public override bool IsValidMove(int startX, int startY, int targetX, int targetY, Piece[,] board)
        {
            int direction = (PieceColor == PlayerColor.White) ? 1 : -1;

            // Vérification du mouvement de base vers l'avant (une case)
            if (startX == targetX && startY + direction == targetY && board[targetY, targetX] == null)
            {
                hasMoved = true;
                return true;
            }

            // Double mouvement initial (deux cases vers l'avant)
            if (!hasMoved && startX == targetX && startY + 2 * direction == targetY && board[startY + direction, startX] == null && board[targetY, targetX] == null)
            {
                hasMoved = true;
                return true;
            }

            // Captures diagonales
            if ((startX + 1 == targetX || startX - 1 == targetX) && startY + direction == targetY)
            {
                Piece targetPiece = board[targetY, targetX];
                if (targetPiece != null && targetPiece.PieceColor != PieceColor)
                {
                    hasMoved = true;
                    return true;
                }
            }

            return false; // Si le mouvement n'est pas valide
         
        }
    }

}
