﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{

    public class Rook : Piece
    {
        public Rook(PlayerColor color) : base(color) { Symbol = "R"; }

        

        public override bool IsValidMove(int startX, int startY, int targetX, int targetY, Piece[,] board)
        {
            // Vérification du mouvement vertical ou horizontal
            if (startX != targetX && startY != targetY)
                return false;

            int xDirection = (startX == targetX) ? 0 : (targetX - startX > 0) ? 1 : -1;
            int yDirection = (startY == targetY) ? 0 : (targetY - startY > 0) ? 1 : -1;

            int x = startX + xDirection;
            int y = startY + yDirection;

            // Vérification des cases sur le chemin du mouvement
            while (x != targetX || y != targetY)
            {
                if (board[y, x] != null)
                    return false;

                x += (xDirection != 0) ? xDirection : 0;
                y += (yDirection != 0) ? yDirection : 0;
            }

            // Vérification de la case cible
            Piece targetPiece = board[targetY, targetX];
            return (targetPiece == null || targetPiece.PieceColor != PieceColor);
        }
    }

}
