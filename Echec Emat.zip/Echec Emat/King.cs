﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public class King : Piece
    {
        public King(PlayerColor color) : base(color) { Symbol = "K"; }

       
        public override bool IsValidMove(int startX, int startY, int targetX, int targetY, Piece[,] board)
        {
            int diffX = Math.Abs(targetX - startX);
            int diffY = Math.Abs(targetY - startY);

            // Vérification du mouvement (1 case dans n'importe quelle direction)
            if ((diffX <= 1 && diffY <= 1) && (diffX + diffY > 0))
            {
                Piece targetPiece = board[targetY, targetX];
                return (targetPiece == null || targetPiece.PieceColor != PieceColor);
            }

            return false; // Si le mouvement n'est pas valide
        }
    }

}
