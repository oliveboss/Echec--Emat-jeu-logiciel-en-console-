﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public class Player
    {


        
        public string Name { get; }
        public PlayerColor Color { get; }

        public Player(string name, PlayerColor color)
        {
            Name = name;
            Color = color;
          
        }
    }

}
