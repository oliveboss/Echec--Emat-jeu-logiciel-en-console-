﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public enum PlayerColor
    {
        White,
        Black
    }


    public abstract class Piece
    {
        public string Symbol { get; set; }

    
    
    public PlayerColor PieceColor { get; protected set; }
        public bool HasMoved { get; set; }
        public Piece(PlayerColor color)
        {
            PieceColor = color;
        }

        public abstract bool IsValidMove(int startX, int startY, int targetX, int targetY, Piece[,] board);
    }

}
