﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{

    class Program
    {



        static void Main(string[] args)
        {
            Board chessBoard = new Board(new Player("Player 2", PlayerColor.White), new Player("Player 1", PlayerColor.Black));

            while (true)
            {
                Console.Clear();
                chessBoard.DisplayBoard(chessBoard);
                


                Console.WriteLine($"Tour du  {chessBoard.CurrentPlayer.Name} (Color: {chessBoard.CurrentPlayer.Color.ToString()}). Chosissez votre deplacement  (exemple: e2e4): ");

                try
                {


                    string move = Console.ReadLine();




                   
                        // Convertir la chaîne du mouvement en coordonnées
                        int startX = move[0] - 'a'; // Récupère la coordonnée X de départ à partir de la lettre (a = 0, b = 1, etc.)
                        int startY = 8 - (move[1] - '0'); // Récupère la coordonnée Y de départ à partir du chiffre (8 = 0, 7 = 1, etc.)
                        int targetX = move[2] - 'a'; // Récupère la coordonnée X d'arrivée
                        int targetY = 8 - (move[3] - '0'); // Récupère la coordonnée Y d'arrivée




                        chessBoard.MakeMove(startX, startY, targetX, targetY);


                  

                    // Vérification de l'échec après le mouvement
                    if (chessBoard.IsKingInCheck(chessBoard.CurrentPlayer.Color))
                    {
                        Console.WriteLine($"Le roi {chessBoard.CurrentPlayer.Color.ToString()} est en échec !");
                        Console.ReadLine();
                        
                    }


                    if (chessBoard.IsKingCaptured(chessBoard.CurrentPlayer.Color, chessBoard.GetBoard()))
                    {
                        
                        Console.WriteLine($"Echec Emat");
                        Console.WriteLine($"Le roi du joueur {chessBoard.CurrentPlayer.Name} a été capturé !");
                        Console.WriteLine("La partie est terminée ! Affichage de l'historique des coups :");
                        Console.ReadLine();

                        // Affichage de l'historique pour chaque joueur
                        Console.WriteLine("Historique des coups pour le Joueur 1 :");
                        foreach (var dep in chessBoard.GetPlayer1Moves())
                        {
                            Console.Write($"{dep} ");
                        }
                        Console.WriteLine();

                        Console.WriteLine("Historique des coups pour le Joueur 2 :");
                        foreach (var dep in chessBoard.GetPlayer2Moves())
                        {
                            Console.Write($"{dep} ");
                        }
                        Console.WriteLine();

                        break;
                    }
                    if (chessBoard.IsStalemate(chessBoard.CurrentPlayer.Color))
                    {
                        Console.WriteLine("Stalemate !/n Partie nulle !!");
                        Console.ReadLine();

                        Console.WriteLine("Affichage de l'historique des coups:");
                        Console.ReadLine();
                        // Affichage de l'historique pour chaque joueur
                        Console.WriteLine("Historique des coups pour le Joueur 1 :");
                        foreach (var dep in chessBoard.GetPlayer1Moves())
                        {
                            Console.Write($"{dep} ");
                        }
                        Console.WriteLine();

                        Console.WriteLine("Historique des coups pour le Joueur 2 :");
                        foreach (var dep in chessBoard.GetPlayer2Moves())
                        {
                            Console.Write($"{dep} ");
                        }
                        Console.WriteLine();

                        break;
                    }







                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erreur de saisie. Veuillez entrer un mouvement valide.");
                    Console.WriteLine($"Exception : {ex.Message}");

                    Console.ReadLine();
                }

                
            }
        }


      

       


     

    }
    }



